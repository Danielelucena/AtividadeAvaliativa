package entidade;

public class Pessoa {
    public String nome;
    private int idade;
    protected String endereço;
    int telefone;

    public Pessoa(String nome, int idade, String endereço, int telefone) {
        this.nome = nome;
        this.idade = idade;
        this.endereço = endereço;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    @Override
    public String toString() {
        return "entidade.Pessoa{" +
                "nome='" + nome + '\'' +
                ", idade=" + idade +
                ", endereço='" + endereço + '\'' +
                ", telefone=" + telefone +
                '}';
    }
}
