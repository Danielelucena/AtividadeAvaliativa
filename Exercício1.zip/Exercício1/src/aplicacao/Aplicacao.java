package aplicacao;

import entidade.Pessoa;

import java.util.Scanner;

public class Aplicacao extends Pessoa {
    public Aplicacao(String nome, int idade, String endereço, int telefone) {
        super(nome, idade, endereço, telefone);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite seu nome: ");
        String nome = sc.nextLine();
        System.out.println("Digite sua idade: ");
        int idade = sc.nextInt();
        System.out.println("Digite seu endereço:");
        String endereco = sc.nextLine();
        sc.nextLine();
        System.out.println("Digite seu telefone: ");
        int telefone = sc.nextInt();

        Pessoa pessoas = new Pessoa(nome, idade, endereco, telefone);
        System.out.println(pessoas);
    }
}
