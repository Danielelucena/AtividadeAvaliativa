package principal;

import entidade.Imposto;
import entidade.ImpostoPessoaFisica;
import entidade.ImpostoPessoaJuridica;

public class CalculadoraImposto {
    public static void main(String[] args) {
        Imposto[] impostos = new Imposto[2];

        ImpostoPessoaJuridica pessoaJuridica = new ImpostoPessoaJuridica(100);
        ImpostoPessoaFisica pessoaFisica = new ImpostoPessoaFisica(100);
        pessoaJuridica.calcularImposto();
        pessoaFisica.calcularImposto();


    }
}