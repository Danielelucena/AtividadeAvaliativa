package entidade;

public interface Imposto {
abstract void calcularImposto();
}
