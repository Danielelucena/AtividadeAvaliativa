package entidade;

public class ImpostoPessoaJuridica implements Imposto{
private double rendaAnual;

    public ImpostoPessoaJuridica(double rendaAnual) {
        this.rendaAnual = rendaAnual;
    }

    public double calcularImpostoJurico() {
        return 0;
    }


    public double getRendaAnual() {
        return rendaAnual;
    }

    public void setRendaAnual(double rendaAnual) {
        this.rendaAnual = rendaAnual;
    }

    @Override
    public void calcularImposto() {
        System.out.println(this.rendaAnual*0.1);

    }
}
