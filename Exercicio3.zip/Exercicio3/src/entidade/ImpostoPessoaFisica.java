package entidade;

public class ImpostoPessoaFisica implements Imposto{
    private double rendaAnual;

    public ImpostoPessoaFisica(double rendaAnual) {
        this.rendaAnual = rendaAnual;
    }

    public void calcularImpostoFisico(){

    }

    public double getRendaAnual() {
        return rendaAnual;
    }

    public void setRendaAnual(double rendaAnual) {
        this.rendaAnual = rendaAnual;
    }

    @Override
    public void calcularImposto() {
        System.out.println(this.rendaAnual*0.2);
    }
}
