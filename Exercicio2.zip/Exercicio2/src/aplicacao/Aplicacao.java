package aplicacao;

import entidade.Livro;

import java.util.Scanner;

public class Aplicacao extends Livro{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Qual o título do livro:");
        String titulo = sc.nextLine();
        System.out.println("Qual o nome do autor:");
        String autor = sc.nextLine();
        System.out.println("Qual o ano de publicação:");
        int anoPublicacao = sc.nextInt();
        System.out.println("Qual o preço do livro:");
        double preco = sc.nextDouble();

        Livro livros = new Livro(titulo, autor, anoPublicacao, preco);
        System.out.println(livros);

    }
}
