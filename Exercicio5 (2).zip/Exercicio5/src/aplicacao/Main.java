package aplicacao;

import entidade.Produto;
import entidade.ProdutoImpl;

public class Main {
    public static void main(String[] args) {
        Produto produto = new ProdutoImpl("aplicacao", 50);

        System.out.println("Produto: " + produto.getNome());
        System.out.println("Quantidade em estoque: " + produto.getQuantidade());

        produto.adicionarQuantidade(20);
        System.out.println("Quantidade após adicionar 20: " + produto.getQuantidade());

        produto.removerQuantidade(10);
        System.out.println("Quantidade após remover 10: " + produto.getQuantidade());

        produto.removerQuantidade(100);
    }
}
