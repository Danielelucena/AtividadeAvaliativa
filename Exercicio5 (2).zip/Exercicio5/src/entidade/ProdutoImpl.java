package entidade;

public class ProdutoImpl implements Produto {
    private String nome;
    private int quantidade;


    public ProdutoImpl(String nome, int quantidade) {
        this.nome = nome;
        this.quantidade = quantidade;
    }


    @Override
    public String getNome() {
        return nome;
    }


    @Override
    public int getQuantidade() {
        return quantidade;
    }


    @Override
    public void adicionarQuantidade(int quantidade) {
        if (quantidade > 0) {
            this.quantidade += quantidade;
        } else {
            System.out.println("Quantidade a adicionar deve ser positiva.");
        }
    }


    @Override
    public void removerQuantidade(int quantidade) {
        if (quantidade > 0 && this.quantidade >= quantidade) {
            this.quantidade -= quantidade;
        } else {
            System.out.println("Quantidade a remover deve ser positiva e não pode exceder o estoque atual.");
        }
    }
}
