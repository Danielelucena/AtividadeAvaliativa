package entidade;

public class List<T> {
    public void add(T item) {

    }
}
