package entidade;

import java.util.ArrayList;

public class Pedido implements PedidoRestaurante {


        @Override
        public void adicionarItem(String item, double preco) {

        }

        @Override
        public double calcularTotal() {
                return 0;
        }
}
