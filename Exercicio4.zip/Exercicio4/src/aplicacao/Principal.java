package aplicacao;

import entidade.Pedido;
import entidade.PedidoRestaurante;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Qual seu pedido:");
        String pedido1 = sc.nextLine();
        System.out.println(pedido1 + 20.0);

        System.out.println("Qual seu pedido:");
        String pedido2 = sc.nextLine();
        System.out.println(pedido2 + 20.0);

        System.out.println("O valor total é de: "+ 40.00);

    }
}