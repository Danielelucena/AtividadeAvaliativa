package aplicacao;

public class Produto {
    public String getNome() {
        return nome;
    }
}
