package aplicacao;

import entidade.ProdutoImpl;

public class Main {
    public class Main {
        public static void main(String[] args) {
            Produto produto = new ProdutoImpl("Produto A", 50);

            System.out.println("Nome do produto: " + produto.getNome());
            System.out.println("Estoque atual: " + produto.getQuantidade());

            // Adicionando quantidade
            produto.adicionarQuantidade(20);
            System.out.println("Novo estoque após adicionar 20: " + produto.getQuantidade());

            // Removendo quantidade
            produto.removerQuantidade(15);
            System.out.println("Novo estoque após remover 15: " + produto.getQuantidade());

            // Tentativa de remoção com quantidade insuficiente
            produto.removerQuantidade(80); // Deve exibir mensagem de quantidade insuficiente
        }
    }
}
