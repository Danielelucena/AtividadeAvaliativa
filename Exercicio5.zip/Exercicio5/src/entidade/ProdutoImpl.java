package entidade;

public class ProdutoImpl implements Produto {
    private String nome;
    private int quantidade;

    // Construtor
    public ProdutoImpl(String nome, int quantidade) {
        this.nome = nome;
        this.quantidade = quantidade;
    }

    @Override
    public String getNome() {
        return nome;
    }

    @Override
    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public int getQuantidade() {
        return quantidade;
    }

    @Override
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public void adicionarQuantidade(int quantidade) {
        if (quantidade > 0) {
            this.quantidade += quantidade;
        } else {
            throw new IllegalArgumentException("A quantidade deve ser positiva.");
        }
    }

    @Override
    public void removerQuantidade(int quantidade) {
        if (quantidade > 0) {
            if (this.quantidade >= quantidade) {
                this.quantidade -= quantidade;
            } else {
                System.out.println("Quantidade insuficiente para remoção.");
            }
        } else {
            throw new IllegalArgumentException("A quantidade deve ser positiva.");
        }
    }
}