public interface Produto {
    String getNome();
    void setNome(String nome);
    int getQuantidade();
    void setQuantidade(int quantidade);

    void adicionarQuantidade(int quantidade);
    void removerQuantidade(int quantidade);
}